﻿namespace Order.Domain.ValueObjects
{
    public enum ProductType
    {
        Website,
        PaidSearch
    }
}
